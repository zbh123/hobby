from person import Person
from student import Student

stu = Student('tom', 18, 1000)
print(stu.name, stu.age)
stu.run()
stu.eat('apple')
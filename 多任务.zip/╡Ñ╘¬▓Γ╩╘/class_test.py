


class Person(objct):
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def getValue(self):
        return self.age

per = Person('lala', 16)






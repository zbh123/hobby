'''
单元测试：
作用：用来对一个函数或者一个类、一个函数来进行正确性校验工作


'''



def mySum(x,y):
    return x+y

def mySub(x,y):
    return x-y













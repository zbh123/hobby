'''

css的属性：
1、浮动：float:left/right
2、定位：position:fixed/absolute/relative
        fixed:固定在窗口中的位置，不因滚动而改变位置
        absolute:一般为子级定位，需要在父级的基础上使用，即在父级的实体的位置
        relative:一般为父级定位，使用后，可以固定子级的位置






'''
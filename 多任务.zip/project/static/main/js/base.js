$(document).ready(function(){
//    innerWidth屏幕大小，对应的css中的rem，每rem= 下面的值
    document.documentElement.style.fontSize = innerWidth / 10 + "px";

})
import urllib.request

urllib.request.urlretrieve('http//:www.baidu.com', filename=r"D:\\ruanjian\matplot_test\爬虫\\baidu.html")


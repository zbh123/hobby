import tkinter


#创建主窗口
win = tkinter.Tk()

#设置标题
win.title('heheh')
#设置大小和位置
win.geometry('400x400+200+20')
win.mainloop()
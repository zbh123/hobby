# flake8: noqa
from .view import ModelView

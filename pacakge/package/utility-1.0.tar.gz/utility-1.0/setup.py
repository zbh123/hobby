from distutils.core import setup

setup(name='utility',
	  version='1.0',
	  url='https://tmthyjames@bitbucket.org/tmthyjames/utilitybelt.git',
	  packages=[''],
	  maintainer='tim dobbins',
	  maintainer_email='tmthyjames@gmail.com',
	  description='functions i use often'
	  )
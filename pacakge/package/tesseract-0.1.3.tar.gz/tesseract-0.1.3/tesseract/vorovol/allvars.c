/*! \file allvars.c
 *  \brief provides instances of all global variables
 */

#include "allvars.h"

char ParameterFile[MAXLEN_FILENAME];

struct parameters All;

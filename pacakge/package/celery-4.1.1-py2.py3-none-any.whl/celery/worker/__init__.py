"""Worker implementation."""
from __future__ import absolute_import, unicode_literals
from .worker import WorkController

__all__ = ['WorkController']

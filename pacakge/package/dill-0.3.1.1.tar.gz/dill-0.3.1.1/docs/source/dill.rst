dill module documentation
=========================

dill module
-----------

.. automodule:: dill._dill
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members:

detect module
-------------

.. automodule:: dill.detect
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members: ismethod, isfunction, istraceback, isframe, iscode, parent, reference, at, parents, children

objtypes module
---------------

.. automodule:: dill.objtypes
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members:

pointers module
---------------

.. automodule:: dill.pointers
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members:

settings module
---------------

.. automodule:: dill.settings
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members:

source module
-------------

.. automodule:: dill.source
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members:

temp module
-----------

.. automodule:: dill.temp
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :show-inheritance:
    :imported-members:
..  :exclude-members:


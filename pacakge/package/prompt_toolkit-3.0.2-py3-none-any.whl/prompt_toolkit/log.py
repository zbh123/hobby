"""
Logging configuration.
"""
import logging

__all__ = [
    "logger",
]

logger = logging.getLogger(__package__)
